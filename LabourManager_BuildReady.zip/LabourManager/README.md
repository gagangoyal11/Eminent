# Labour Manager – Android

Offline labour attendance and expense manager for electrical/contracting work.

Features:
- Labour master: daily rate, overtime rate, mobile
- Project/site master
- Daily attendance + overtime hours
- Regular payment and advance payment records
- Other expenses by category
- Monthly dashboard and labour-wise report
- CSV report sharing to WhatsApp/Email/Excel
- Local SQLite storage; no internet required

Open the project in Android Studio and run on an Android phone. The project intentionally uses standard Android APIs and no external libraries.
